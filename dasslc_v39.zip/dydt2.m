function [res,ires]=dydt2(t,y,yp,rpar)

res(1)=yp(1) - y(2);

switch rpar
    case 0
        res(2)=yp(2) + y(1); 
    case 1
        res(2)=y(2) - cos(t); 
    case 2
        res(2)=y(1) - sin(t);
end

ires = 0;
