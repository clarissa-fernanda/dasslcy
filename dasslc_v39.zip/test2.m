% Dasslc test2 problem
% requires files: dydt2.m

t0  = 0.0;      % initial value for independent variable
tf  = 2*pi;     % final value for independent variable
y0  = [0 1]';   % initial state variables
rtol= 1e-6;     % relative tolerance
atol= 1e-8;     % absolute tolerance
index = [0 0;1 1;1 2];
rpar = 2; %index

tspan=[t0:0.01:tf];
[t,y,yp,outp]=dasslc('dydt2',tspan,y0,[],rpar,rtol,atol,index(rpar+1,:));
plot(t,y)
