/*
 * $Log:        daDemo.c,v $
 * Revision 2.5  2005/07/09  10:25  arge
 * DASSLC version
 *
 * examples used in DDASSL by Linda Petzold.
 */

#include "dasslc.h"
#include <math.h>

DASSLC_RES res1;
DASSLC_JAC jac1;

DASSLC_RES res2;
DASSLC_JAC jac2;

REAL edit2 (REAL *, REAL);

void
main ()
{
 PTR_ROOT root;
 FAST int i;
 BOOL error;
 REAL t = 0., tout, y[25], yp[25], res[25], y0, er, er1, er2, er0 = 0.;

 if (error = daSetup ("daDemo1.dat", &root, res1, 0, t, NULL, NULL, NULL, NULL, NULL), error)
 {
  printf ("Setup error = %d\n", error);
  exit(1);
 }

 for (tout = 1.0, i = 0; i < 10; i++)
    {
     if (error = dasslc (TRANSIENT, &root, res1, &t, tout, jac1, NULL), error < 0)
       {
		printf ("error = %d\n", error);
		break;
       }

     y0 = exp ((double)-10. * t);
     er1 = fabs ((double)y0 - root.y[0]);
     er2 = fabs ((double)1. - y0 - root.y[1]);
     er = MAX (er1, er2) / *root.iter.atol;
     if (er > er0) er0 = er;

     fprintf (root.savefile, "*** STEPSIZE = %g, ORDER = %d\n\n",
	      (double)root.bdf.hold, root.bdf.orderold);

     if (er >= 1000.0)
       fprintf (root.savefile, "*** WARNING: error exceeds 1000 * tolerance\n\n");

     tout += 1.0;
    }

 fprintf (root.savefile, "*** ERROR OVERRUN = %g\n\n", (double)er0);
 daStat (root.savefile, &root);
 daFree (&root);

 t = 0.0;

 for (i = 1; i < 25; i++)
    {
     res[i] = y[i] = 0.0;
    }
 y[0] = 1.0;
 res[0] = 0.0;

 error = FALSE;
 res2 (&root, t, y, res, yp, &error);

 if (error = daSetup ("daDemo2.dat", &root, res2, 25, t, y, yp, NULL, NULL, NULL), error)
 {
  printf ("Setup error = %d\n", error);
  exit(1);
 }

 for (tout = 0.01, i = 0; i < 5; i++)
    {
     if (error = dasslc (TRANSIENT, &root, res2, &t, tout, jac2, NULL), error < 0)
       {
		printf ("error = %d\n", error);
		break;
       }

     er1 = edit2 (root.y, t);
     er = er1 / *root.iter.atol;
     if (er > er0) er0 = er;

     fprintf (root.savefile, "*** STEPSIZE = %g, ORDER = %d\n",
	      (double)root.bdf.hold, root.bdf.orderold);
     fprintf (root.savefile, "*** MAXIMUM ERROR = %g\n\n", (double)er1);

     if (er >= 1000.0)
       fprintf (root.savefile, "*** WARNING: error exceeds 1000 * tolerance\n\n");

     tout *= 10;
    }

 fprintf (root.savefile, "*** ERROR OVERRUN = %g\n\n", (double)er0);
 daStat (root.savefile, &root);
 daFree (&root);
}					/* main */

BOOL
res1 (PTR_ROOT *root, REAL t, REAL *y, REAL *yp, REAL *res, BOOL *jac)
{
 res[0] = yp[0] + 10.0 * y[0];
 res[1] = y[1] + y[0] - 1.0;

 return FALSE;
}					/* res1 */

#define PD(i,j) (*(pd + rank * (i) + j))

BOOL
jac1 (PTR_ROOT *root, REAL t, REAL *y, REAL *yp, REAL cj, void *ja, DASSLC_RES *res)
{
 int rank = root -> rank;
 REAL *pd = (REAL *)ja;

 PD(0,0) = cj + 10.0;
 PD(0,1) = 0.0;
 PD(1,0) = 1.0;
 PD(1,1) = 1.0;

 return FALSE;
}					/* jac1 */

BOOL
res2 (PTR_ROOT *root, REAL t, REAL *y, REAL *yp, REAL *res, BOOL *jac)
{
 PRIV REAL alph1 = 1.0, alph2 = 1.0;
 REAL d;
 PRIV int ng = 5;
 FAST int i, j, k;

 for (j = 0; j < ng; j++)
    for (k = j * ng, i = 0; i < ng; i++, k++)
       {
	d = -2.0 * y[k];

	if (i) d += y[k-1] * alph1;
	if (j) d += y[k-ng] * alph2;

	res[k] = d - yp[k];
       }

 return FALSE;
}					/* res2 */

#define PD(i,j) (*(pd + rank * (i) + j))
BOOL                                            /* pd comes cleaned */
jac2 (PTR_ROOT *root, REAL t, REAL *y, REAL *yp, REAL cj, void *ja, DASSLC_RES *res)
{
#ifdef SPARSE
 char *pd = (char *)ja;
#else
 REAL *pd = (REAL *)ja;
#endif /* SPARSE */
 FAST int j;
 int rank = root -> rank;
 PRIV REAL alph1 = 1.0, alph2 = 1.0;
 PRIV int ng = 5;

 for (j = 0; j < rank; j++)
    {
#ifdef SPARSE
     daSparse_set (pd, j, j, -2.0 - cj);
     if (j + 1 < rank && (j + 1) % ng) daSparse_set (pd, j + 1, j, alph1);
     if (j + 5 < rank) daSparse_set (pd, j + 5, j, alph2);
#else
     PD(j,j) = -2.0 - cj;
     if (j + 1 < rank && (j + 1) % ng) PD(j+1,j) = alph1;
     if (j + 5 < rank) PD(j+5,j) = alph2;
#endif /* SPARSE */
    }

 return FALSE;
}					/* jac2 */

REAL
edit2 (REAL *y, REAL t)
{
 PRIV REAL alph1 = 1.0, alph2 = 1.0;
 PRIV int ng = 5;
 REAL erm = 0., ex, a2, a1, yt, er;
 register int i, j, k;

 if (!t) return erm;

 ex = 0.0;
 if (t <= 30.0) ex = exp ((double)-2.0 * t);

 a2 = 1.0;
 for (j = 0; j < ng; j++)
    {
     a1 = 1.0;
     for (i = 0; i < ng; i++)
	{
	 k = i + j * ng;
	 yt = pow ((double)t, (double)(i + j)) * ex * a1 * a2;
	 er = fabs ((double)(y[k] - yt));
	 if (er > erm) erm = er;
	 a1 *= alph1 / (double)(i+1);
	}
     a2 *= alph2 / (double)(j+1);
    }

 return erm;
}					/* edit2 */
