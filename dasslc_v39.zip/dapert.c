/*
 * $Log:        daPert.c,v $
 * Revision 1.0  97/07/23  17:25  {arge}
 * DASSLC version
 *
 */

/*
  This program reads a perturbation file (binary) created by DASSLC
  with the "option savepert" together with "option sparsemode eval"
  and print its content in a nice format.
  The differential-algebraic dependency matrix 'dep' is set according to:
       0 - if the equation does not involve the current 'y' and 'yp'
       1 - if the equation involves the current 'y' but not 'yp'
       2 - if the equation involves the current 'yp' but not 'y'
       3 - if the equation involves both current 'y' and 'yp'
*/

#include "dasslc.h"
#include <math.h>
#ifdef UNIX
#  include <strings.h>
#  define stricmp strcasecmp
#else
#  include <string.h>
#endif /* UNIX */

#define EXIT	{fprintf (stderr, \
		 "***ERROR daPert: error reading pertfile\n"); \
		 exit (1);}

void
main (int argc, char **argv)
{
 FILE *fp;
 FAST int i, j;
 BOOL flag = FALSE;
 int rank, size, *index, off;
 char *pertfile, *dep, nl[2][18] = {"", "\n               "}, buf[16];

 if (argc < 3) flag = TRUE;
 else
   {
    rank = atoi (argv[1]);
    if (rank <= 0)
      {
       fprintf (stderr, "***ERROR daPert: Error in system size = %d\n", rank);
       flag = TRUE;
      }
    else
      {
       pertfile = argv[2];
       if (!(fp = fopen (pertfile, "rb"), fp))
	 {
	  fprintf (stderr, "***ERROR daPert: Cannot open perturbation file \"%s\"\n",
		   pertfile);
	  flag = TRUE;
	 }
      }
   }

 if (flag)
   {
    puts ("usage: dapert <system size> <pertfile> [dep]");
    exit (1);
   }

 if (argc > 3) flag = !stricmp (argv[3], "dep");

 dep = (char *)must_malloc (rank, "DEP");
 index = NEW (int, rank, "INDEX");

 fprintf (stdout, "*** DASSLC - Differential/Algebraic System Solver in C *** Version 2.0\n");
 fprintf (stdout, "Perturbation file: %s    ---    System size: %d\n", pertfile, rank);
 fprintf (stdout, "Notation --> row #: <variable list>\n");
 if (flag)
   {
    fprintf (stdout, "         --> dep #: <dependency list>\n");
    fprintf (stdout, "with dependency:\n"
       "0 - if the equation # does not involve the current 'y' and 'yp'\n"
       "1 - if the equation # involves the current 'y' but not 'yp'\n"
       "2 - if the equation # involves the current 'yp' but not 'y'\n"
       "3 - if the equation # involves both current 'y' and 'yp'\n");
   }


 for (i = 0; i < rank; i++)             /* read structure from pertfile */
    {
     if (fread ((char *)&size, sizeof (int), 1, fp) < 1) EXIT;

     if (size < 0 || size > rank)
       {
	fprintf (stderr, "***ERROR daPert: Size (%d) not correct in file \"%s\"\n",
		 size, pertfile);
	exit (1);
       }

     if (fread (dep, 1, size, fp) < (unsigned)size) EXIT;
     if (fread ((char *)index, sizeof (int), size, fp) < (unsigned)size) EXIT;

     if (size)
       {
	fprintf (stdout, "\nrow %d:", i);
	off = sprintf (buf, "%d", i);
	nl[1][6+off] = '\0';

	for (j = 0; j < size; j++)
	   fprintf (stdout, "%s %d", nl[!((j + 1) % 15)], index[j]);

	if (flag)
	  {
	   fprintf (stdout, "\ndep %d:", i);

	   for (j = 0; j < size; j++)
	      fprintf (stdout, "%s %d", nl[!((j + 1) % 15)], dep[j]);
	  }

	nl[1][6+off] = ' ';
       }
    }

 fprintf (stdout, "\n");
 free (dep);
 free (index);
 fclose (fp);
}                            /* main */


/* must_malloc; malloc n bytes, exit if not successful */
void *
must_malloc (unsigned n, char *s)
{
 void *p = malloc (n);

 if (p == NULL && n)
   {
    fprintf (stderr, "***ERROR must_malloc: \"%s\": not enough memory\n", s);
    exit (1);
   }

 return p;
}					/* must_malloc */
